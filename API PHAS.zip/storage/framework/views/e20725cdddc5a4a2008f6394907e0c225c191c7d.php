

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="text-center text-secondary">DATA GURU</h3>
    <?php if($messege = Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_create')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('failed_create')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_edit')): ?>
    <div class="alert alert-warning alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <div class="text-left">




            </div>

            <div class="text-right">
                <a type="button" class="btn btn-primary" href="/guru/create/index">
                    <i class="fas fa-user-plus"> </i> Tambah Data
                </a>
            </div>

        </div>


        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="example2">
                    <thead class="text-center">
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Foto</th>
                            <th>Aksi</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no =1;
                        ?>
                        <?php $__currentLoopData = $data_guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center fw-normal">
                            <td><?php echo e($no++); ?> </td>
                            <td><?php echo e($dtg->name); ?></td>
                            <td><?php echo e($dtg->username); ?></td>
                            <td><?php echo e($dtg->email); ?></td>
                            <td class="col-3"><img width="50px" height="50px" src=" <?php echo e($dtg->photo_profil); ?>" alt=""></td>
                            <td>

                                <a href="" data-toggle="modal" data-target="#edit<?php echo e($dtg->id); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit text-white"></i></a>

                                <a href="/guru/delete/<?php echo e($dtg->id); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>

                            </td>
                        </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

    <!-- modal edit data -->
    <?php $__currentLoopData = $data_guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="edit<?php echo e($dtg->id); ?>">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Form Edit Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/guru/edit" method="post">
                        <?php echo csrf_field(); ?>
                        <input name="id" type="hidden" value="<?php echo e($dtg->id); ?>">
                        <div class="row mt-3">
                            <div class="col-2">
                                <label for="" class="form-label">Name</label>
                            </div>
                            <div class="col-8"><input value="<?php echo e($dtg->name); ?>" name="name" class="form-control" type="text" required></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-2">
                                <label for="" class="form-label">Email</label>
                            </div>
                            <div class="col-8"><input value="<?php echo e($dtg->email); ?>" name="email" class="form-control" type="email" required></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-2">
                                <label for="" class="form-label">Username</label>
                            </div>
                            <div class="col-8"><input value="<?php echo e($dtg->username); ?>" name="username" class="form-control" type="text" required></div>
                        </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-warning text-white">Edit Data</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkSpace\laravel\project\API PHAS\resources\views/guru/index.blade.php ENDPATH**/ ?>