

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="text-center text-secondary">DATA KEPALA SEKOLAH </h3>
    <?php if($messege = Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_create')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('failed_create')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_edit')): ?>
    <div class="alert alert-warning alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <div class="text-left">




            </div>

            <div class="text-right">
                <?php if($len_kepala_sekolah === 0): ?>
                <a type="button" class="btn btn-primary" href="/kepala-sekolah/create/index">
                    <i class="fas fa-user-plus"> </i> Tambah Data
                </a>
                <?php endif; ?>

            </div>

        </div>


        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="example2">
                    <thead class="text-center">
                        <tr>

                            <th>Name</th>
                            <th>Email</th>
                            <th>Foto</th>
                            <th>Aksi</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_kepala_sekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                        <tr class="text-center fw-normal">

                            <td><?php echo e($dtks->name); ?></td>

                            <td><?php echo e($dtks->email); ?></td>
                            <td class="col-3"><img width="50px" height="50px" src=" <?php echo e($dtks->photo_profil); ?>" alt=""></td>
                            <td>

                                <!-- <a href="" data-toggle="modal" data-target="#edit<?php echo e($dtks->id); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit text-white"></i></a> -->

                                <a href="/kepala-sekolah/delete/<?php echo e($dtks->id); ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
            </div>
        </div>
    </div>

    <!-- modal edit data -->


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkSpace\laravel\project\API PHAS\resources\views/kepala_sekolah/index.blade.php ENDPATH**/ ?>