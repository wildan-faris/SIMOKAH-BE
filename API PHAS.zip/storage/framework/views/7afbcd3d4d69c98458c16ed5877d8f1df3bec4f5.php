
<?php $__env->startSection('title', 'orang_tua'); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $data_orang_tua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <h3 class="text-center text-secondary">DATA ORANG TUA</h3>
    <?php if($messege = Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_create')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('failed_create')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_edit')): ?>
    <div class="alert alert-warning alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <div class="text-left">




            </div>



        </div>


        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="example2">
                    <thead class="text-center">
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>NIS</th>
                            <th>Tahun Ajaran</th>
                            <th>Kelas</th>
                            <th>Aksi</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no =1;
                        ?>
                        <?php $__currentLoopData = $dtot->siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <tr class="text-center fw-normal">
                            <td><?php echo e($no++); ?> </td>
                            <td><?php echo e($dts->name); ?></td>
                            <td><?php echo e($dts->nis); ?></td>
                            <td><?php echo e($dts->tahun_ajaran); ?></td>
                            <td><?php echo e($dts->kelas->name); ?></td>

                            <td>


                                <a href="/siswa/delete/<?php echo e($dts->id); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>

                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
            </div>
        </div>
    </div>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkSpace\laravel\project\API PHAS\resources\views/orang_tua/view.blade.php ENDPATH**/ ?>