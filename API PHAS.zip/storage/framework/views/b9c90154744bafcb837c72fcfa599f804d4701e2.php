

<?php $__env->startSection('content'); ?>



<div class="container">
    <h3 class="text-center text-secondary">TAMBAH DATA AHLI PARENTING</h3>


    <div class="card  center-auto justify-content-center">
        <div class="card-header">
            <div class="text-right">
                <a href="/ahli-parenting/index" class="btn btn-primary text-auto"><i class="fas fa-eye"></i> Lihat Data</a>
            </div>
        </div>
        <div class="card-body">
            <form action="/ahli-parenting/create" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row mt-3">
                    <div class="col-2">
                        <label for="" class="form-label">Name</label>
                    </div>
                    <div class="col-8"><input name="name" class="form-control" type="text" required></div>
                </div>
                <div class="row mt-3">
                    <div class="col-2">
                        <label for="" class="form-label">Email</label>
                    </div>
                    <div class="col-8"><input name="email" class="form-control" type="email" required></div>
                </div>

                <div class="row mt-3">
                    <div class="col-2">
                        <label for="" class="form-label">Password</label>
                    </div>
                    <div class="col-8"><input name="password" class="form-control" type="password" required></div>
                </div>


                <div class="mt-3 ml-auto ">
                    <input type="submit" class="btn btn-success" value="Tambah Data">
                </div>
            </form>
        </div>
    </div>

</div>




</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkSpace\laravel\project\API PHAS\resources\views/ahli_parenting/create.blade.php ENDPATH**/ ?>