

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="text-center text-secondary">DATA GRAFIK <?php echo e(strtoupper($data_kelas->name)); ?></h3>
    <?php if($messege = Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_create')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('failed_create')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_edit')): ?>
    <div class="alert alert-warning alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php endif; ?>

    <!-- session untuk admin -->

    <div class="card">
        <div class="card-header">
            <div class="text-left">
            </div>
        </div>
        <?php $__currentLoopData = $data_aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="card-body">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="far fa-chart-bar"></i>
                        <?php echo e($dta->name); ?>

                    </h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col">
                        <?php $__currentLoopData = $dta->sub_aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtasb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div class="row align-items-end mb-3">
                            <div class="col-md-2">
                                <?php echo e($dtasb->name); ?>

                            </div>
                            <div class="col-md-10">
                                <?php $__currentLoopData = $data_total_nilai_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dttnk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($dttnk->kelas_id == $data_kelas->id): ?>
                                <?php if($dttnk->sub_aktivitas_id == $dtasb->id): ?>

                                <?php echo e($dttnk->nilai); ?>

                                <?php
                                $grafik = $dttnk->nilai * 20;
                                ?>
                                <div class="" style="width: <?php echo e($grafik); ?>%; height:20px; background-color:#05BFDB;"></div>



                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>



                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>
    <?php $__env->startSection('scripts'); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkSpace\laravel\project\API PHAS\resources\views/kelas/grafik_kelas.blade.php ENDPATH**/ ?>