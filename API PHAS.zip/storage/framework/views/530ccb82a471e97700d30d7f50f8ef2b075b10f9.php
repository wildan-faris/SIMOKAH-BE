
<?php $__env->startSection('title', 'Kelas'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="text-center text-secondary">DATA <?php echo e(strtoupper($data_kelas->name)); ?></h3>
    <?php if($messege = Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_create')): ?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('failed_create')): ?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_edit')): ?>
    <div class="alert alert-warning alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php elseif($messege= Session::get('success_delete')): ?>
    <div class="alert alert-danger alert-dismissible text-white" role="alert">
        <strong><?php echo e($messege); ?>


    </div>
    <?php endif; ?>

    <!-- session untuk admin -->

    <div class="card">
        <div class="card-header">
            <div class="text-left">




            </div>

            <div class="text-right">
                <a type="button" class="btn btn-primary" href="/kelas/grafik/kelas/<?php echo e($data_kelas->id); ?>">
                    <i class="fas fa-chart-pie"></i> Data Grafik Kelas
                </a>
                <a type="button" class="btn btn-primary" href="/kelas/grafik/kelas/bulan/<?php echo e($data_kelas->id); ?>">
                    <i class="fas fa-chart-pie"></i> Data Grafik Bulanan Kelas
                </a>
            </div>

        </div>


        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="example2">
                    <thead class="text-center">
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Tahun Ajaran</th>
                            <th>Nama Orang Tua</th>
                            <th>Aksi</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no =1;
                        ?>
                        <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center fw-normal">
                            <td><?php echo e($no++); ?> </td>
                            <td><?php echo e($dts->name); ?></td>
                            <td><?php echo e($dts->tahun_ajaran); ?></td>
                            <td><?php echo e($dts->orang_tua->name); ?></td>

                            <td>
                                <a href="/kelas/grafik/siswa/<?php echo e($dts->id); ?>" class="btn btn-sm btn-primary"><i class="fas fa-chart-pie text-white"></i></a>


                            </td>
                        </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WorkSpace\laravel\project\API PHAS\resources\views/kelas/view.blade.php ENDPATH**/ ?>